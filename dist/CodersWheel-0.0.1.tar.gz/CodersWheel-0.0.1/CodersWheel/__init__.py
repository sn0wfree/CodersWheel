# -*- coding: utf-8 -*-
__Version__ = '0.0.1'
__Author__ = 'sn0wfree'
