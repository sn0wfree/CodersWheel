# -*- coding: utf-8 -*-
# Copyright by sn0wfree 2018
# ----------------------------
#


class Core(object):

    def __init__(self):
        pass


if __name__ == '__main__':
    pass
